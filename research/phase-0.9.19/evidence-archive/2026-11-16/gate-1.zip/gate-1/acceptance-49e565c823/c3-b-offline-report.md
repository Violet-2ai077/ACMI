# ACMI Phase 0.9.19 Gate 1 offline report

Fake transport only. No research GO and no pooled context score.

## C1

| Arm / track | Attempts | User F1 | State snapshot |
| --- | ---: | ---: | ---: |
| Unobserved | 0 | N/A | N/A |

## C2

| Arm / track | Attempts | User F1 | State snapshot |
| --- | ---: | ---: | ---: |
| Unobserved | 0 | N/A | N/A |

## C3

| Arm / track | Attempts | User F1 | State snapshot |
| --- | ---: | ---: | ---: |
| B / CLOSED-LOOP | 8 | 1 | 0.9285714285714286 |

## Diagnostic D

0 development diagnostic entries; excluded from A/B and GO.

## Unverified

- live model ability
- real streaming
- token overhead
- confirmatory intervals
- production integration
