# dsh integration timeout diagnosis

Date: 2026-11-15. This is an offline integration-test investigation, not a model
experiment or R-E/R-A performance acceptance.

## Finding

The existing dsh test is sensitive to full-suite worker concurrency. With the
installed Vitest 4.1.12, 12 available logical CPUs and no explicit worker limit,
the local implementation resolves the default worker limit to 11. The 5000 ms
test timeout is unchanged. The timeout is cumulative across tool operations and
history reads, not evidence of an attribution assertion failure.

Temporary phase markers reproduced the failure after first-page history query
and during cursor validation. The exact low-level contention source (CPU, disk,
filesystem filtering or scheduling) has not been isolated and is not asserted.

| Observation | Isolated dsh file | Default full suite | Four-worker full suite |
| --- | ---: | ---: | ---: |
| Setup complete, cumulative ms | 51 | 109 | 78 |
| First bind duration, ms | 18 | 735 | 25 |
| Second bind duration, ms | 17 | 550 | 21 |
| History query duration, ms | 69 | 417 | 72 |
| History render duration, ms | 68 | 653 | 84 |
| First page duration, ms | 55 | 776 | 97 |
| First page complete, cumulative ms | 434 | 4670 | 585 |
| Finished callback, cumulative ms | 556 | 5032 (timeout) | 848 |
| Test outcome | 6/6 | 275/276 | 276/276 |

The full-suite instrumented four-worker run took 31.05 s versus 32.49 s for the
failed default run. These individual diagnostic observations are not a statistical
performance claim or qualification of the research ledger.

## Controls and verification

- Pre-merge research suite: 208/208. Post-merge research suite: 208/208.
- Feature checkout default checks failed twice on the same existing dsh timeout.
- Original main default `pnpm check` passed before integration; post-merge default
  failed on that same timeout. One instrumented default run also passed, confirming
  that a successful retry alone cannot establish a fix.
- The instrumented default-stderr run reproduced the timeout with phase timings.
- Full Vitest suite with one worker: 276/276, unchanged tests/timeouts.
- Full instrumented suite with four workers: 276/276, unchanged assertions/timeouts.
- All temporary source instrumentation was removed with an exact clean Git diff.
- On merged main, uninstrumented `pnpm check` with process-local
  `VITEST_MAX_WORKERS=4` passed: lint/build, 276 Vitest tests, 30 model-continuation
  offline tests and all three demo commands. The environment variable was restored
  after the command. No permanent package/CI/runtime configuration was changed.
- No skipped tests, timeout increases, model calls, freeze changes or new research
  stopping conditions were used. Original failed logs are preserved.

## Proposed remediation, not yet applied

Use an explicit bounded Vitest worker budget (four workers was validated here),
rather than CPU-count-derived concurrency for this I/O-heavy suite. Retain the
5000 ms limit, all assertions and test coverage. Validate any permanent command/CI
change separately; local four-worker success does not prove all runners stable.

Main is locally merged at `1f0cf1ed0be48ce3f1deb15b4a759e9a55569057`; the source
commit is `1c590a3`. Both worktrees are clean after removing instrumentation.
Push remains paused; no claim that the default configuration has been fixed.

## Evidence in this directory

- `workspace-before-merge.log`, `workspace-serial-final.log`: initial default failures.
- `workspace-serial-before-merge.log`: missing-final-newline lint finding in an
  imported artifact; resolved by preserving the original under a `.raw` suffix,
  without changing its bytes or relaxing the source checker.
- `dsh-isolated.log`, `workspace-one-worker.log`: initial isolation controls.
- `main-baseline-default.log`, `workspace-after-merge.log`: main baseline/merge results.
- `research-before-merge.log`, `research-after-merge.log`: 208-test research checks.
- `dsh-timing-instrumentation.patch`, `dsh-timing-default.log`: initial console
  marker probe; console markers were not surfaced, so this is not timing evidence.
- `dsh-timing-stderr.patch`, `dsh-timing-isolated.log`,
  `dsh-timing-default-stderr.log`, `dsh-timing-four-workers.log`: captured timing probe.
- `main-four-workers-check.log`: complete uninstrumented bounded-worker check.
